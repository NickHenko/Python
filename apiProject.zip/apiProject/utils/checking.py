"""Методы для проверки ответов наших запросов"""
import json

from requests import Response
from colorama import Fore

class Checking():

    """Метод для проверки статус кода"""
    @staticmethod
    def check_status_code(response: Response, status_code):
        assert status_code == response.status_code
        if response.status_code == status_code:
            print(Fore.LIGHTGREEN_EX, "Успешно! Статус код = " + str(response.status_code), Fore.RESET)
        else:
            print(Fore.LIGHTRED_EX, "Ошибка! Статсус код = " + str(response.status_code), Fore.RESET)

    """Метод для проверки наличия обязательных полей в ответе запроса"""
    @staticmethod
    def check_json_token(response: Response, expected_value):
        token = json.loads(response.text)
        assert list(token) == expected_value
        print(Fore.LIGHTGREEN_EX, "Все поля присутствуют!", Fore.RESET)

    """Метод для проверки значений обязательных полей в ответе запроса"""
    @staticmethod
    def check_json_value(response: Response, field_name, expected_value):
        check = response.json()
        check_ifo = check.get(field_name)
        assert check_ifo == expected_value
        print(Fore.LIGHTGREEN_EX, field_name + " верен! ", Fore.RESET)

    """Метод для проверки значений обязательных полей в ответе запроса по заданному слову"""
    @staticmethod
    def check_json_search_word_in_value(response: Response, field_name, search_word):
        check = response.json()
        check_ifo = check.get(field_name)
        if search_word in check_ifo:
            print(Fore.LIGHTGREEN_EX, "Слово " + search_word + " присутствует! ", Fore.RESET)
        else:
            print(Fore.LIGHTRED_EX, "Слово " + search_word + "отсутсвует!", Fore.RESET)










